# FZ.ADS - Landing final

Instrucciones:
1. Descomprimir el ZIP.
2. Subir todo el contenido al repositorio en GitHub (Add file → Upload files).
3. Activar GitHub Pages en Settings → Pages (branch: main, folder: /root).
4. Esperar 1-2 minutos y abrir la URL pública.

Contacto: WhatsApp +54 3794 332820
