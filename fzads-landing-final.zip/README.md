# 🌐 FZ.ADS Landing Profesional

Landing page moderna y animada para FZ.ADS — lista para publicar en GitHub Pages.

## 🚀 Cómo publicarla
1. Crea un repositorio en GitHub (ej: `fzads-landing`).
2. Sube todos los archivos de esta carpeta (no el ZIP entero).
3. Ve a **Settings → Pages → Source → Deploy from branch (main/root)**.
4. Guarda y espera 1-2 minutos.

Tu sitio estará disponible en:
```
https://tuusuario.github.io/fzads-landing
```

Desarrollado con ❤️ por FZ.ADS
