# FZ.ADS - Landing final (mejorada)

Instrucciones rápidas:
1. Descomprime y sube el contenido al repo de GitHub (Add file -> Upload files).
2. Activá GitHub Pages en Settings -> Pages (branch: main, folder: root).
3. Esperá 1-2 minutos y accedé a la URL que te provea GitHub.

Incluye:
- index.html, styles.css, script.js
- assets/*.png (avatares, favicon, preview)

Contacto: WhatsApp +54 3794 332820 (formulario envía mensaje preformateado).
